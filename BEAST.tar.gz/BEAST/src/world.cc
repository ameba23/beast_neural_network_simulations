/*
 * \file world.cc
 * The implementation of World.
 */

#include "world.h"
#include "animat.h"

using namespace std;

namespace BEAST {

/**
 * Constructor, simply configures the world's monitor and collisions classes.
 */
World::World(): updateInProgress(false)
{
	monitor.SetWorld(this);
	collisions.SetWorld(this);
	SetColour(ColourPalette[COLOUR_DARK_PURPLE]);
}

/**
 * Calls Init on every Animat and WorldObject in the World. Usually called at
 * the start of a simulation, to allow objects to be set up correctly (e.g.
 * defining display lists and performing configuration which can't be done til
 * an object knows which World it's in.
 * \see WorldObject::Init
 * \see Animat::Init
 */
void World::Init()
{
	for_each(worldobjects.begin(), worldobjects.end(), mem_fun(&WorldObject::Init));
	for_each(animats.begin(), animats.end(), mem_fun(&Animat::Init));
}

/**
 * Sets up GL with the correct background colour, projection mode and blend
 * function.
 */
void World::InitGL()const
{
	glClearColor(disp.colour[0], disp.colour[1], disp.colour[2], 1.0f);

	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0, disp.width, 0, disp.height);
	glMatrixMode(GL_MODELVIEW);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE); // for sensors
}	

/**
 * Called every frame and responsible for calling Update on every WorldObject
 * and Animat in the World.
 * \see WorldObject::Update
 * \see Animat::Update
 */
void World::Update()
{
	updateInProgress = true;

	UpdateMouse();

	// Update every object in the world.
	for_each(worldobjects.begin(), worldobjects.end(), mem_fun(&WorldObject::Update));
	for_each(animats.begin(), animats.end(), mem_fun(&Animat::Update));

	worldobjects.erase(
		remove_if(worldobjects.begin(), worldobjects.end(),
				  mem_fun(&WorldObject::IsDead)),
		worldobjects.end());
	animats.erase(
		remove_if(animats.begin(), animats.end(), 
				  mem_fun(&Animat::IsDead)),
		animats.end());

	if (!animats.empty()) {
		// Interactions:
		AnimatIter j, k;

		AnimatIter first = animats.begin();
		AnimatIter last = animats.end();
		AnimatIter secondlast = animats.end() - 1;

		// Each Animat interacts with each WorldObject:
		for (WorldObjectIter i = worldobjects.begin(); i != worldobjects.end(); ++i)
			for (j = first; j != last; ++j)
				(*j)->Interact(*i);

		// Each Animat interacts with each Animat.
		for (j = first; j != secondlast; ++j)
			for (k = ++first; k != last; ++k)
				(*j)->Interact(*k);
	}

	collisions.Update();
	updateInProgress = false;
	UpdateQueues();
}

/**
 * Adds an Animat to the World's animat container, set's the Animat's world to
 * this one and adds a pointer to the Animat to the monitor object.
 * \param r A pointer to the Animat to be added.
 */
void World::Add(Animat* r)
{
	if (!updateInProgress) animats.push_back(r);
	else animatQueue.push_back(r);
	r->SetWorld(this);
	monitor.push_back(r);
}

/**
 * Adds a WorldObject to the World's worldobject container and set's the
 * WorldObject's world to this one.
 * \param r A pointer to the WorldObject to be added.
 */
void World::Add(WorldObject* r)
{
	if (!updateInProgress) worldobjects.push_back(r);
	else worldobjectQueue.push_back(r);
	r->SetWorld(this);
}

/**
 * Clears all containers in this World.
 */
void World::CleanUp()
{
	animats.clear();
	worldobjects.clear();
	collisions.clear();
	monitor.clear();
	mouse.current = NULL;
	mouse.selected = NULL;
}

/**
 * Calls the Display method of every object in the world, depending on this
 * World's DisplayInfo struct.
 * \see DisplayInfo
 * \see WorldDisplayType
 */
void World::Display()
{
	glClear(GL_COLOR_BUFFER_BIT);

	if ((disp.config & DISPLAY_WORLDOBJECTS) != 0) {
		for_each(worldobjects.begin(), worldobjects.end(),
				 mem_fun(&WorldObject::Display));
	}
	if ((disp.config & DISPLAY_ANIMATS) != 0) {
		for_each(animats.begin(), animats.end(), mem_fun(&Animat::Display));
	}
	
	if (mouse.selected != NULL) {
		glColor4fv(ColourPalette[COLOUR_SELECTION]);
		Vector2D pos = mouse.selected->GetLocation();
		glEnable(GL_BLEND);
		glPushMatrix();
			GLUquadricObj* Disk;
			Disk = gluNewQuadric();
			gluQuadricDrawStyle(Disk, GLU_FILL);
			glTranslated(pos.x, pos.y, 0.0);
			gluDisk(Disk, 0, mouse.selected->GetRadius() + 5.0, 16, 1);
			gluDeleteQuadric(Disk);
		glPopMatrix();
		glDisable(GL_BLEND);
	}

	if ((disp.config & DISPLAY_COLLISIONS) != 0) collisions.Display();
	if ((disp.config & DISPLAY_MONITOR) != 0) monitor.Display();
}

void World::OnMouseLDown(int x, int y)
{
	if (mouse.right) return;

	mouse.left = true;
	mouse.location = WindowXY(x, y);

	for (AnimatIter i = animats.begin(); i != animats.end(); ++i) {
		if ((*i)->IsInside(mouse.location)) {
			(*i)->OnClick();
			if ((*i)->IsMoveable()) mouse.current = *i;
			if ((*i)->IsSelectable()) mouse.selected = *i;
			if ((*i)->IsMoveable() || (*i)->IsSelectable()) break;
		}
	}
	if (mouse.current == NULL) {
		for (WorldObjectIter i = worldobjects.begin();
			 i != worldobjects.end(); ++i) {
			if ((*i)->IsInside(mouse.location)) {
				(*i)->OnClick();
				if ((*i)->IsMoveable()) mouse.current = *i;
				if ((*i)->IsSelectable()) mouse.selected = *i;
				if ((*i)->IsMoveable() || (*i)->IsSelectable()) break;
			}
		}
	}
	if (mouse.current == NULL) mouse.selected = NULL;
	else mouse.current->OnSelect();
}

void World::OnMouseRDown(int x, int y)
{
	mouse.right = true;

	if (mouse.current != NULL) {
		mouse.staticLocation = mouse.location;
	}
}

void World::OnMouseLUp(int x, int y)
{
	mouse.left = false;
	mouse.location = WindowXY(x, y);

	if (mouse.current != NULL) {
		if (!mouse.right) {
			mouse.current->SetLocation(mouse.location);
		}
		mouse.current = NULL;
	}
}

void World::OnMouseRUp(int x, int y)
{
	mouse.right = false;

	if (mouse.left) {
		mouse.current = NULL;
	}
}

void World::OnMouseMove(int x, int y)
{
	mouse.location = WindowXY(x, y);
}

void World::OnSelectNext()
{
	AnimatIter a = animats.end();

	if (mouse.selected != NULL) {
		a = find(animats.begin(), animats.end(), mouse.selected);
	}

	if (a == animats.end()) {
		a = find_if(animats.begin(), animats.end(), mem_fun(&WorldObject::IsSelectable));
	}

	if (a != animats.end()) {
		AnimatIter b = a;
		++a;
		for (; a != b; ++a) {
			if (a == animats.end()) a = animats.begin();
			if ((*a)->IsSelectable()) break;
		}
		mouse.selected = *a;
		mouse.selected->OnSelect();
	}
	else {
		mouse.selected = NULL;
		return;
	}
}

void World::OnSelectPrevious()
{
	AnimatContainer::reverse_iterator a = animats.rend();

	if (mouse.selected != NULL) {
		a = find(animats.rbegin(), animats.rend(), mouse.selected);
	}

	if (a == animats.rend()) {
		a = find_if(animats.rbegin(), animats.rend(), mem_fun(&WorldObject::IsSelectable));
	}

	if (a != animats.rend()) {
		AnimatContainer::reverse_iterator b = a;
		++a;
		for (; a != b; ++a) {
			if (a == animats.rend()) a = animats.rbegin();
			if ((*a)->IsSelectable()) break;
		}
		mouse.selected = *a;
	}
	else {
		mouse.selected = NULL;
		return;
	}
}

Vector2D World::WindowXY(int x, int y)
{
	return Vector2D((static_cast<double>(x) / disp.winWidth) * disp.width, 
				  ((disp.winHeight - static_cast<double>(y)) / disp.winHeight) * disp.height);
}

void World::UpdateMouse()
{
	if (mouse.current == NULL) return;

	if (mouse.left) { 
		if (mouse.right) {
			mouse.current->SetOrientation((mouse.location - mouse.current->GetLocation()).GetAngle());
			mouse.current->SetLocation(mouse.staticLocation);
		}
		else {
			mouse.current->SetLocation(mouse.location);
		}
	} 
	return;	
}

void World::UpdateQueues()
{
	copy(animatQueue.begin(), animatQueue.end(),
		 inserter(animats, animats.end()));
	animatQueue.clear();

	copy(worldobjectQueue.begin(), worldobjectQueue.end(),
		 inserter(worldobjects, worldobjects.end()));
	worldobjectQueue.clear();
}

} // namespace BEAST
