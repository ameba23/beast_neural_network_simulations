#include "beast.h"

/**
 * This application loads the BEAST library and a specified plugin, and
 * runs the simulation in non-graphical mode.
 * Usage: beastbatch <plugin> <simulation>
 */
int main(int argc, char* argv[])
{
	using namespace std;
	using namespace BEAST;

	if (argc < 3 || (argc >= 2 && argv[1] == "--help")) { 
		cout << "Usage: " << argv[0] << " <plugin> <simulation> [<simulation object> <output file> ...]" << endl;
		return 1;
	}

	vector<string> names;
	vector<GetSimulationBase*> funcs;

	if (!LoadPlugin(argv[1], names, funcs)) {
		cout << "Error loading plugin " << argv[1] << endl;
		return 1;
	}

	Simulation* theSim = NULL;
	int i;
	
	for (i=0; i < static_cast<int>(names.size()); ++i) {
		if (names[i] == argv[2]) {
			cout << "Starting simulation: " << names[i] << "..." << endl;
			theSim = funcs[i]->Get();
			break;
		}
	}
	
	if (i == static_cast<int>(names.size())) {
		cout << "Simulation: " << argv[2] << " not found." << endl;
		return 1;
	}

	string filename;
	
	theSim->SetLogStream(cout);
	theSim->Init();
	
	for (int j=3; j < argc - 1; j+=2)
		if (!theSim->HasSimObject(argv[j])) {
			cout << "There is no simulation object called " << argv[j] << '\n';
			return 1;
		}
		else cout << "Simulation object " << argv[j] << " will be saved in file "
				  << argv[j + 1] << '\n';
	
	while(theSim->Update());

	// Save all the specified simulation objects
	for (int j=3; j < argc - 1; j+=2)
		theSim->GetSimObject(argv[j]).Save(argv[j + 1]);
	
	return 0;
}

